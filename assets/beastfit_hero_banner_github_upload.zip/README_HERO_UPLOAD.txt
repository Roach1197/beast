BEASTFIT HERO BANNER UPDATE

Upload the contents of this ZIP to your GitHub repo.

Main file to replace:
assets/hero-athlete.jpg

Why:
Your site CSS already uses assets/hero-athlete.jpg for the homepage hero image.
Replacing that file updates the hero banner without changing code.

Steps:
1. Unzip this file.
2. Open your GitHub repo: Roach1197/beast
3. Open the assets folder.
4. Upload hero-athlete.jpg and replace the existing file.
5. Commit the change.
6. Netlify should auto-deploy.
7. Hard refresh the site with Ctrl + F5.

Optional:
hero-athlete-original.png is included as the untouched PNG backup.
You do not need to upload it unless you want a backup in the repo.
