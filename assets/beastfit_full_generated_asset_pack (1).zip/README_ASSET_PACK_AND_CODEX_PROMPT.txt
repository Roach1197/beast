BEASTFIT FULL GENERATED ASSET PACK

Upload the /assets files into your GitHub repo:

Roach1197/beast/assets/

IMPORTANT:
- The first 7 files use the SAME filenames your current CSS already references:
  hero-athlete.jpg
  story-lifter.jpg
  hoodies.jpg
  tees.jpg
  shorts.jpg
  hats.jpg
  texture.jpg

Uploading those will immediately replace current visuals after Netlify deploys.

NEW STANDALONE PAGE ASSETS INCLUDED:
- about-hero.jpg
- about-motivation-poster.jpg
- shop-hero.jpg
- contact-hero.jpg
- fit-guide-hero.jpg
- drop-flatlay.jpg
- product-rack.jpg
- product-display.jpg

EXTRAS INCLUDED:
- alternate-hero-blue.jpg
- alternate-story-brooding.jpg
- alternate-cap-gold.jpg
- alternate-gear-flatlay.jpg

Recommended GitHub commit message:
Replace BeastFit site imagery with full generated asset pack

After uploading, tell Codex:

Use Roach1197/beast.

I uploaded a new full BeastFit asset pack into /assets.

Use these:
- hero-athlete.jpg for homepage hero
- story-lifter.jpg for the homepage mindset/story section
- hoodies.jpg, tees.jpg, shorts.jpg, hats.jpg for collection/category and product cards
- about-hero.jpg for the About page hero
- about-motivation-poster.jpg as a motivational visual section on About
- shop-hero.jpg for the Shop page header
- fit-guide-hero.jpg for a new standalone Fit Guide page
- contact-hero.jpg for a new standalone Contact page
- drop-flatlay.jpg or product-display.jpg for product/drop sections where useful

Tasks:
1. Remove the remaining ghosted/mockup text on the left side of the homepage hero.
2. Create standalone fit-guide.html and contact.html pages.
3. Update nav links so Fit Guide and Contact go to their own pages, not homepage anchors.
4. Improve the About page with a stronger motivational brand section and use about-hero.jpg instead of the old close-up hero crop.
5. Keep the existing black/gold aggressive BeastFit style.
6. Do not add frameworks, build tools, React, Tailwind, or dependencies.
7. Keep the project static HTML/CSS/JS.
8. Preserve current pages and sections unless cleaning them up.
9. Improve desktop first, then mobile.
10. Commit directly to main and summarize changed files.

